# Golden Crust Bakery Website

## Student Information
- **Name:** [Your Full Name]
- **Student Number:** [Your Student Number]
- **Subject:** Digital Transformation and Systems (DITS5111)

## Project Overview
This repository contains the source code for the Golden Crust Bakery website,
developed as part of the DITS5111 Portfolio of Evidence (PoE). Golden Crust
Bakery is a hypothetical family-owned bakery based in Johannesburg, and this
project showcases the design and development of a professional, responsive
website for the organisation across three phases: HTML structure (Part 1),
CSS styling (Part 2), and JavaScript functionality (Part 3).

## Website Goals and Objectives
- Establish a professional online presence for Golden Crust Bakery.
- Enable customers to browse products and submit custom cake/catering enquiries online.
- Reduce reliance on phone enquiries by providing clear information (location, hours, menu).

## Key Features and Functionality
- Homepage with hero section and featured products.
- About Us page detailing history, mission, vision, and team.
- Products page listing bread, cakes, and pastries.
- Enquiry page with a custom order form.
- Contact page listing two locations with maps and a contact form.

## Timeline and Milestones
- **Part 1 (Planning):** Organisation selection, proposal approval, content research, sitemap, initial HTML structure.
- **Part 2 (Styling):** CSS styling applied across all pages, responsive design.
- **Part 3 (Functionality):** JavaScript functionality, testing, debugging, SEO optimisation.

## Part 1 Details
Part 1 focused on project initiation and planning: selecting Golden Crust
Bakery as the target organisation, drafting and gaining approval for the
website project proposal, conducting content research, creating the sitemap,
and building the initial HTML structure for all five pages (Home, About,
Products, Enquiry, Contact).

*(Part 2 and Part 3 details will follow in future submissions/edits.)*

## Sitemap
See `sitemap.png` in this repository for the visual sitemap.

```
Homepage (index.html)
├── About Us (about.html)
├── Products (products.html)
│   ├── Bread
│   ├── Cakes
│   └── Pastries
├── Enquiry (enquiry.html)
└── Contact (contact.html)
    ├── Main Bakery location
    └── Kiosk location
```

## File Structure
```
golden-crust-bakery/
├── index.html
├── about.html
├── products.html
├── enquiry.html
├── contact.html
├── sitemap.png
├── css/
├── js/
└── images/
```

## Changelog
- **[Date]** – Initial commit: project folder structure created.
- **[Date]** – Added HTML structure for all 5 pages (index, about, products, enquiry, contact).
- **[Date]** – Added sitemap diagram.

## References
*(To be compiled using the Harvard referencing style adapted for the IIE, combining
references from the Website Project Proposal with any additional sources used
during content research and HTML development.)*
