# Sources and Attribution

## Text Content
All written content (homepage, about, products, and contact page copy) is original
content created specifically for this project, for the hypothetical organisation
Golden Crust Bakery. No external text was copied.

## Images
The images currently in the `images/` folder are placeholder graphics generated for
development purposes to represent the intended photography (bread, cakes, pastries,
storefront, team, hero banner). These placeholders must be replaced before final
submission with real, legally sourced images from a reputable free-stock site, and
each one recorded below per the Harvard referencing style adapted for the IIE.

### Recommended Free Stock Sources
- Unsplash: https://unsplash.com/s/photos/artisan-bread (free for commercial use, no attribution required)
- Pexels: https://www.pexels.com/search/bakery/ (free for commercial use, no attribution required)
- Pixabay: https://pixabay.com/images/search/bakery/ (Pixabay Licence, free for commercial use)

### Image Citation Log
*(Fill in one entry per image, once selected and downloaded. Example format below.)*

| File used for | Description | Source | Image URL | Date accessed | Licence |
|---|---|---|---|---|---|
| hero-placeholder.jpg | Hero banner - fresh bread | Unsplash | [paste exact image page URL] | [date] | Unsplash Licence |
| bread-placeholder.jpg | Artisan bread loaves | | | | |
| cakes-placeholder.jpg | Custom celebration cake | | | | |
| pastries-placeholder.jpg | Assorted pastries | | | | |
| bakery-storefront-placeholder.jpg | Bakery storefront | | | | |
| baker-placeholder.jpg | Head baker | | | | |
| cake-decorator-placeholder.jpg | Cake decorator | | | | |
| sourdough-placeholder.jpg | Sourdough loaf | | | | |
| rye-placeholder.jpg | Rye bread | | | | |
| wholewheat-placeholder.jpg | Whole wheat loaf | | | | |
| birthday-cake-placeholder.jpg | Birthday cake | | | | |
| wedding-cake-placeholder.jpg | Wedding cake | | | | |
| croissant-placeholder.jpg | Butter croissant | | | | |
| muffin-placeholder.jpg | Muffins | | | | |
| logo-placeholder.png | Bakery logo | *(self-designed or from a free logo maker)* | | | |

**Harvard-style reference example** (adapt per the IIE's adapted guide):
Unsplash (2026) *Artisan bread loaf* [Photograph]. Available at: [exact URL] (Accessed: [date]).

## Pricing Research
Product pricing was estimated based on general research into comparable small
bakery pricing in South Africa and is illustrative rather than sourced from a
specific real business.

*(Update this file with full citations as real assets are sourced.)*
