# Products Page Content Source

## Bread
- Sourdough Loaf – R55 – Slow-fermented for a rich flavour and crisp crust.
- Rye Bread – R60 – Dense and hearty, made with a blend of rye and wheat flour.
- Whole Wheat Loaf – R50 – A wholesome everyday loaf, soft on the inside with a golden crust.

## Cakes
- Birthday Cakes – From R450 – Custom designed and flavoured cakes for any celebration.
- Wedding Cakes – From R1,800 – Elegant multi-tier cakes tailored to your wedding theme.

## Pastries
- Butter Croissants – R25 – Flaky, buttery croissants baked fresh each morning.
- Muffins – R20 – Available in blueberry, chocolate chip, and banana flavours.

*Note: Pricing is illustrative, based on general research into comparable South African
bakery pricing, for this hypothetical organisation.*
