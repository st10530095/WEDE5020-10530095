# About Page Content Source

## History
Golden Crust Bakery is a family-owned bakery based in Johannesburg, established in 2015.
It began as a small home-baking operation run out of a family kitchen and has since grown
into a beloved neighbourhood bakery known for artisanal bread, custom cakes, and pastries.
Over the past decade, the bakery has built a loyal local customer base primarily through
word-of-mouth and community events.

## Mission
To bring high-quality, freshly baked goods to the community using traditional baking
techniques and locally sourced ingredients.

## Vision
To become the go-to bakery for celebrations and everyday treats across Johannesburg,
known for consistency, warmth, and craftsmanship.

## Team
- Head Baker: Leads daily bread and pastry production with over 10 years of baking experience.
- Cake Decorator: Designs and decorates every custom celebration cake by hand.

*Note: All content above is original, written for this project (hypothetical organisation).*
