# Homepage Content Source

## Hero Headline
Freshly Baked, Every Day

## Hero Subtext
Artisanal bread, custom cakes, and pastries made with love in the heart of Johannesburg.

## Introduction Paragraph
Since 2015, Golden Crust Bakery has been baking fresh bread, custom cakes, and pastries
for the local Johannesburg community. What started as a small home-baking operation has
grown into a beloved neighbourhood bakery, built on traditional techniques and locally
sourced ingredients.

## Featured Product Blurbs
- Artisanal Bread: Sourdough, rye, and whole-wheat loaves baked fresh every morning.
- Custom Cakes: Birthday, wedding, and celebration cakes designed to order.
- Pastries: Croissants, muffins, and sweet treats baked daily.

*Note: All content above is original, written for this project (hypothetical organisation).*
